package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class BeanTestSupport {
    private BeanTestSupport() {}

    public static void assertNoArgsConstructorAndAccessors(Class<?> type) throws Exception {
        Object instance = type.getDeclaredConstructor().newInstance();
        for (Field field : type.getDeclaredFields()) {
            if (field.isSynthetic()) continue;
            Object value = sampleValue(field.getType(), field.getName());
            Method setter = type.getMethod("set" + capitalize(field.getName()), field.getType());
            Method getter = getter(type, field);
            setter.invoke(instance, value);
            assertEquals(value, getter.invoke(instance), "Field accessor mismatch: " + field.getName());
        }
    }

    public static void assertAllArgsConstructor(Class<?> type) throws Exception {
        Field[] fields = Arrays.stream(type.getDeclaredFields())
                .filter(f -> !f.isSynthetic())
                .toArray(Field[]::new);
        Class<?>[] parameterTypes = Arrays.stream(fields).map(Field::getType).toArray(Class<?>[]::new);
        Object[] values = Arrays.stream(fields).map(f -> sampleValue(f.getType(), f.getName())).toArray();

        Constructor<?> constructor = type.getDeclaredConstructor(parameterTypes);
        Object instance = constructor.newInstance(values);

        for (int i = 0; i < fields.length; i++) {
            Method getter = getter(type, fields[i]);
            assertEquals(values[i], getter.invoke(instance), "All args constructor mismatch: " + fields[i].getName());
        }
    }

    public static void assertBuilder(Class<?> type) throws Exception {
        Method builderMethod = type.getMethod("builder");
        Object builder = builderMethod.invoke(null);
        Class<?> builderType = builder.getClass();

        Field[] fields = Arrays.stream(type.getDeclaredFields())
                .filter(f -> !f.isSynthetic())
                .toArray(Field[]::new);

        Object[] values = new Object[fields.length];
        for (int i = 0; i < fields.length; i++) {
            Field field = fields[i];
            Object value = sampleValue(field.getType(), field.getName());
            values[i] = value;
            Method chainMethod = builderType.getMethod(field.getName(), field.getType());
            Object returnedBuilder = chainMethod.invoke(builder, value);
            assertSame(builder, returnedBuilder, "Builder should be chainable for: " + field.getName());
        }

        Object instance = builderType.getMethod("build").invoke(builder);
        for (int i = 0; i < fields.length; i++) {
            Method getter = getter(type, fields[i]);
            assertEquals(values[i], getter.invoke(instance), "Builder mismatch: " + fields[i].getName());
        }
    }

    private static Method getter(Class<?> type, Field field) throws NoSuchMethodException {
        String suffix = capitalize(field.getName());
        if (field.getType().equals(boolean.class)) {
            return type.getMethod("is" + suffix);
        }
        return type.getMethod("get" + suffix);
    }

    private static Object sampleValue(Class<?> fieldType, String fieldName) {
        if (fieldType.equals(String.class)) return fieldName + "-value";
        if (fieldType.equals(Integer.class) || fieldType.equals(int.class)) return 123;
        if (fieldType.equals(Boolean.class) || fieldType.equals(boolean.class)) return true;
        if (List.class.isAssignableFrom(fieldType)) return Collections.singletonList("item");
        try {
            return fieldType.getDeclaredConstructor().newInstance();
        } catch (Exception ignored) {
            return new Object();
        }
    }

    private static String capitalize(String value) {
        return value.substring(0, 1).toUpperCase() + value.substring(1);
    }
}
