package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.config;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class StandardTypeTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(StandardType.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(StandardType.class); }
    @Test void shouldCoverBuilder() throws Exception { assertBuilder(StandardType.class); }
}
