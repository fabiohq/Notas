package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.host.bp17.request;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class TrxBP17DataRequestTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(TrxBP17DataRequest.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(TrxBP17DataRequest.class); }
    @Test void shouldCoverBuilder() throws Exception { assertBuilder(TrxBP17DataRequest.class); }
}
