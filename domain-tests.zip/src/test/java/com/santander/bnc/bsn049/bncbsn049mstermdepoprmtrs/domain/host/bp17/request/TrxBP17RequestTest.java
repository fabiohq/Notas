package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.host.bp17.request;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import org.junit.jupiter.api.Test;

import com.santander.bnc.bsn049.bncbsn049igcdtcommon.domain.trx.generic.TrxPersonHeader;

class TrxBP17RequestTest {

    @Test
    void shouldCoverNoArgsConstructorAndAccessors() throws Exception {
        assertNoArgsConstructorAndAccessors(TrxBP17Request.class);
    }

    @Test
    void shouldCoverAllArgsConstructor() throws Exception {
        assertAllArgsConstructor(TrxBP17Request.class);
    }

    @Test
    void shouldCoverBuilder() throws Exception {
        assertBuilder(TrxBP17Request.class);
    }

    @Test
    void shouldBuildRequestFromTrxPersonHeader() throws Exception {
        TrxPersonHeader header = new TrxPersonHeader();

        setField(header, "canal", "APP");
        setField(header, "rutaServicio", "route-bp17");
        setField(header, "funcion", "function-bp17");
        setField(header, "resultado", "OK");
        setField(header, "secuencia", 77);

        Field sesionField = findField(header.getClass(), "sesion");
        Object sessionSource = sesionField.getType().getDeclaredConstructor().newInstance();
        setField(sessionSource, "entorno", "ENT");
        setField(sessionSource, "fechaContable", "2026-06-11");
        setField(sessionSource, "horaConexion", "10:00:00");
        setField(sessionSource, "perfil", "PERFIL");
        setField(sessionSource, "sucursal", "001");
        setField(sessionSource, "terminal", "TERM");
        setField(sessionSource, "turno", "1");
        setField(sessionSource, "usuario", "USR");
        setField(header, "sesion", sessionSource);

        TrxBP17Request request = new TrxBP17Request(header);

        assertNotNull(request.getCabecera());
        assertNull(request.getData());
        assertEquals("APP", request.getCabecera().getCanal());
        assertEquals("route-bp17", request.getCabecera().getRutaServicio());
        assertEquals("function-bp17", request.getCabecera().getFuncion());
        assertEquals("OK", request.getCabecera().getResultado());
        assertEquals(77, request.getCabecera().getSecuencia());
        assertNotNull(request.getCabecera().getSesion());
        assertEquals("ENT", request.getCabecera().getSesion().getEntidad());
        assertEquals("ENT", request.getCabecera().getSesion().getEntorno());
        assertEquals("2026-06-11", request.getCabecera().getSesion().getFechaContable());
        assertEquals("10:00:00", request.getCabecera().getSesion().getHoraConexion());
        assertEquals("PERFIL", request.getCabecera().getSesion().getPerfil());
        assertEquals("001", request.getCabecera().getSesion().getSucursal());
        assertEquals("TERM", request.getCabecera().getSesion().getTerminal());
        assertEquals("1", request.getCabecera().getSesion().getTurno());
        assertEquals("USR", request.getCabecera().getSesion().getUsuario());
    }

    private static void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = findField(target.getClass(), fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private static Field findField(Class<?> type, String fieldName) throws NoSuchFieldException {
        Class<?> current = type;
        while (current != null) {
            try {
                return current.getDeclaredField(fieldName);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        throw new NoSuchFieldException(fieldName);
    }
}
