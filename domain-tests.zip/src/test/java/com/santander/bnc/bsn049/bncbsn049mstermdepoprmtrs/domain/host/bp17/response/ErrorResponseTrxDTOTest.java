package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.host.bp17.response;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class ErrorResponseTrxDTOTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(ErrorResponseTrxDTO.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(ErrorResponseTrxDTO.class); }
    @Test void shouldCoverBuilder() throws Exception { assertBuilder(ErrorResponseTrxDTO.class); }
}
