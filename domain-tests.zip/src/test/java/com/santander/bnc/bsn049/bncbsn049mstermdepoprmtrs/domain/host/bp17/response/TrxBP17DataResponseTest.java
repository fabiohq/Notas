package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.host.bp17.response;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class TrxBP17DataResponseTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(TrxBP17DataResponse.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(TrxBP17DataResponse.class); }
    @Test void shouldCoverBuilder() throws Exception { assertBuilder(TrxBP17DataResponse.class); }
}
