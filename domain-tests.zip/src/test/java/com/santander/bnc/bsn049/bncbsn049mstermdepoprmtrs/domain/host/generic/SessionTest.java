package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.host.generic;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class SessionTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(Session.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(Session.class); }
    @Test void shouldCoverBuilder() throws Exception { assertBuilder(Session.class); }
}
