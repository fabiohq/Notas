package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.host.generic;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class TrxHeaderTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(TrxHeader.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(TrxHeader.class); }
    @Test void shouldCoverBuilder() throws Exception { assertBuilder(TrxHeader.class); }
}
