package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.integration;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class ApiEntryTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(ApiEntry.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(ApiEntry.class); }
}
