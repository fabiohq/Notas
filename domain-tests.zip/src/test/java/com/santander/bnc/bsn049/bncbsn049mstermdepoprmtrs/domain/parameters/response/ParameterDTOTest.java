package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.parameters.response;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class ParameterDTOTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(ParameterDTO.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(ParameterDTO.class); }
    @Test void shouldCoverBuilder() throws Exception { assertBuilder(ParameterDTO.class); }
}
