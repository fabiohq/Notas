package com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.parameters.response;

import static com.santander.bnc.bsn049.bncbsn049mstermdepoprmtrs.domain.BeanTestSupport.*;

import org.junit.jupiter.api.Test;

class TermDepositParameterResponseTest {
    @Test void shouldCoverNoArgsConstructorAndAccessors() throws Exception { assertNoArgsConstructorAndAccessors(TermDepositParameterResponse.class); }
    @Test void shouldCoverAllArgsConstructor() throws Exception { assertAllArgsConstructor(TermDepositParameterResponse.class); }
    @Test void shouldCoverBuilder() throws Exception { assertBuilder(TermDepositParameterResponse.class); }
}
